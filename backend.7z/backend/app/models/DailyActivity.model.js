module.exports = (sequelize, Sequelize) => {
  const DailyActivity = sequelize.define("DailyActivity", {
    ActivityID: {
      type: Sequelize.INTEGER
    },
    BatchID: {
      type: Sequelize.INTEGER
    }
  }, {
    tableName: 'DailyActivity', // Explicitly set the table name
    timestamps: false // Disable automatic createdAt and updatedAt columns
  });

  return DailyActivity;
};
