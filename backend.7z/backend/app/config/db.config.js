module.exports = {
  HOST: "10.84.3.43",
  PORT: "1433",
  USER: "sa",
  PASSWORD: "Dfgh0000&&",
  DB: "PLM",
  dialect: "mssql",
  pool: {
    max: 10,
    min: 0,
    acquire: 30000,
    idle: 10000
  }
};
